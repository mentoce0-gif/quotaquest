Seasonal Vol.1 — QuotaQuest theme pack
=================================
4 themes: Halloween, Winter, Sakura, Pride

INSTALL
1) Copy the .inc files from themes\ into:
   Documents\Rainmeter\Skins\QuotaQuestHUD\@Resources\Themes\
2) Edit @Resources\..\Variables.inc:
       @includeTheme=#@#Themes/<ThemeName>.inc
3) Rainmeter: right-click the skin -> Refresh.

Web/OBS: load renderers/web/index.html and pick colors, or import a theme JSON.
Not affiliated with Anthropic. "Claude"/"Rainmeter" are trademarks of their owners.
